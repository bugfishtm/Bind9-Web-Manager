<?php 
	/* 	
		.........%%%%%...%%..%%...%%%%...%%..%%..%%%%%%..%%%%%%..%%%%%..
		.........%%..%%..%%%.%%..%%......%%..%%....%%......%%....%%..%%.
		.........%%..%%..%%.%%%...%%%%...%%%%%%....%%......%%....%%%%%..
		.........%%..%%..%%..%%......%%..%%..%%....%%......%%....%%.....
		.........%%%%%...%%..%%...%%%%...%%..%%....%%......%%....%%.....
		................................................................
					PHP DNS Software by Jan-Maurice "Bugfish" Dahlmanns
	*/

	#	Copyright (C) 2026 Jan Maurice Dahlmanns [Bugfish]

	#	This program is free software: you can redistribute it and/or modify
	#	it under the terms of the GNU General Public License as published by
	#	the Free Software Foundation, either version 3 of the License, or
	#	(at your option) any later version.

	#	This program is distributed in the hope that it will be useful,
	#	but WITHOUT ANY WARRANTY; without even the implied warranty of
	#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	#	GNU General Public License for more details.

	#	You should have received a copy of the GNU General Public License
	#	along with this program.  If not, see <https://www.gnu.org/licenses/>.

	/*************************************************************************
		Disable Hardlinking
	*************************************************************************/
	if(!defined("_SQL_USER_")) { @http_response_code(404); Header("Location: ../"); exit(); }
?>
<html>
	<head>
		<title>You are currently blocked...</title>
		<meta name="robots" content="noindex, nofollow">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="icon" href="/favicon.ico">
		
		<!--
			/* 	
				.........%%%%%...%%..%%...%%%%...%%..%%..%%%%%%..%%%%%%..%%%%%..
				.........%%..%%..%%%.%%..%%......%%..%%....%%......%%....%%..%%.
				.........%%..%%..%%.%%%...%%%%...%%%%%%....%%......%%....%%%%%..
				.........%%..%%..%%..%%......%%..%%..%%....%%......%%....%%.....
				.........%%%%%...%%..%%...%%%%...%%..%%....%%......%%....%%.....
				................................................................
							PHP DNS Software by Jan-Maurice "Bugfish" Dahlmanns
			*/

			#	Copyright (C) 2026 Jan Maurice Dahlmanns [Bugfish]

			#	This program is free software: you can redistribute it and/or modify
			#	it under the terms of the GNU General Public License as published by
			#	the Free Software Foundation, either version 3 of the License, or
			#	(at your option) any later version.

			#	This program is distributed in the hope that it will be useful,
			#	but WITHOUT ANY WARRANTY; without even the implied warranty of
			#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
			#	GNU General Public License for more details.

			#	You should have received a copy of the GNU General Public License
			#	along with this program.  If not, see <https://www.gnu.org/licenses/>.		
		-->
		
	</head>
	
	<style>
		
	  html, body {
		padding: 0px 0px 0px 0px;
		margin: 0px 0px 0px 0px;
		border-radius: 0px;
	  }

	  .err-wrap {
		height: 100vh;
		background: #0e0e0f;
		display: flex;
		align-items: center;
		justify-content: center;
		position: relative;
		font-family: 'DM Mono', monospace;
		overflow: hidden;
	  }
	  .err-center {
		text-align: center;
	  }
	  .err-code {
		font-size: 120px;
		font-weight: 300;
		color: #e8e8e6;
		letter-spacing: -4px;
		line-height: 1;
		margin: 0;
	  }
	  .err-divider {
		width: 48px;
		height: 1px;
		background: #3a3a3a;
		margin: 24px auto;
	  }
	  .err-desc {
		font-family: 'DM Sans', sans-serif;
		font-size: 13px;
		font-weight: 300;
		color: #5a5a58;
		letter-spacing: 0.04em;
		max-width: 260px;
		margin: 0 auto;
		line-height: 1.7;
	  }
	  .err-label {
		position: absolute;
		bottom: 20px;
		right: 24px;
		font-size: 10px;
		font-weight: 500;
		letter-spacing: 0.18em;
		color: #2e2e2c;
		text-transform: uppercase;
	  }
	  .err-grid {
		position: absolute;
		inset: 0;
		background-image: linear-gradient(#1a1a1a 1px, transparent 1px), linear-gradient(90deg, #1a1a1a 1px, transparent 1px);
		background-size: 48px 48px;
		opacity: 0.5;
		pointer-events: none;
	  }
	</style>
	
	<body>
		<div class="err-wrap">
		  <div class="err-grid"></div>
		  <div class="err-center">
			<p class="err-code">BLOCKED</p>
			<div class="err-divider"></div>
			<p class="err-desc">Your IP is blacklisted and cannot access this page.</p>
		  </div>
		  <span class="err-label">DNSSHTTP ERROR</span>
		</div>
	</body>

</html>