# Bind9 Web Manager [DNSHTTP]

For Documentation see the file index.html in the docs folder! You can open it with any web browser...

You can find  the documentation here:
https://bugfishtm.github.io/Bind9-Web-Manager/  

You can find the github page here:
https://github.com/bugfishtm/Bind9-Web-Manager

My General Github Project Page is here:  
https://bugfishtm.github.io

## Issues
If you encounter issues or have questions using this software, do not hesitate write us at our Forum on www.bugfish.eu/forum !

## Default Login for Webinterface
Username: admin  
Passwort: changeme

----------------------------------------------------------------
more at www.bugfish.eu   
Made by Jan-Maurice Dahlmanns



