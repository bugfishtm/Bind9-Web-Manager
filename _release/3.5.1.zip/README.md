# Bind9 Web Manager [DNSHTTP]

For Documentation see the file index.html in the docs folder! You can open it with any web browser...

You can find  the documentation here:
https://bugfishtm.github.io/Bind9-Web-Manager/  

You can find the github page here:
https://github.com/bugfishtm/Bind9-Web-Manager

I am planning to make a youtube turorial video about this software. See my channels page for the video - It should be named like this project is.   
My Channel URL is here:  
https://www.youtube.com/channel/UC3cOjFu-MLj8GGDkpeIhqhQ

The place where i usually store such kind of tutorial videos is here:  
https://www.youtube.com/playlist?list=PL6npOHuBGrpBw4hKaalqa1E8tGNNf8KoO
  
If you fo not find a tutorial video inside this playlist, i advise you to keep on using the manual/readme at the github page or my website for help.

My General Github Project Page is here:  
https://bugfishtm.github.io

## Issues
If you encounter issues or have questions using this software, do not hesitate write us at our Forum on www.bugfish.eu/forum !

## Default Login for Webinterface
Username: admin  
Passwort: changeme

----------------------------------------------------------------
more at www.bugfish.eu   
Made by Jan-Maurice Dahlmanns



