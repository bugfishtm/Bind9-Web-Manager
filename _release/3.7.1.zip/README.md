![Bugfish](https://img.shields.io/badge/Bugfish-Software-orange)
![Status](https://img.shields.io/badge/Status-Finished-green)
![License](https://img.shields.io/badge/License-MIT-black)
# Bind9 Web Manager [DNSHTTP]

For Documentation see the file index.html in the docs folder!  
 You can open it with any web browser...

You can find  the documentation here:  
https://bugfishtm.github.io/Bind9-Web-Manager/  

You can find the github page here:  
https://github.com/bugfishtm/Bind9-Web-Manager

My General Github Project Page is here:  
https://bugfishtm.github.io

## Example Image
![plot](./_images/domains.png)

## Example Settings File
Example settings File for Installation can be found in _settings folder!

## Installation
For Installation Informations check the documentation on the _docs folder, or 
at https://bugfishtm.github.io... 

## Issues
If you encounter issues or have questions using this software,  
 do not hesitate write us at our Forum on www.bugfish.eu/forum !

## Webinterface Login   
**Change this Login after Installation!!!**  
Username: admin  
Passwort: changeme

----------------------------------------------------------------
more at www.bugfish.eu   
Made by Jan-Maurice Dahlmanns


