Here are just a few configuration examples.
This script may work with all various hosting systems and environment where you have another software running to manage zones and entries.

If you apply the correct settings in settings.php replication should be possible on all systems running bind. Check the webinterface replication log and domain section for insights!

For more deeper information check the documentation at  
https://bugfishtm.github.io/Bind9-Web-Manager 