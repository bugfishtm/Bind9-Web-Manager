<?php
	/*	__________ ____ ___  ___________________.___  _________ ___ ___  
		\______   \    |   \/  _____/\_   _____/|   |/   _____//   |   \ 
		 |    |  _/    |   /   \  ___ |    __)  |   |\_____  \/    ~    \
		 |    |   \    |  /\    \_\  \|     \   |   |/        \    Y    /
		 |______  /______/  \______  /\___  /   |___/_______  /\___|_  / 
				\/                 \/     \/                \/       \/  Framework Version and Autor Class */	
	class x_class_version {
		public $autor 		= "Bugfish (Jan-Maurice Dahlmanns)";
		public $contact 	= "request@bugfish.eu";
		public $website 	= "https://www.bugfish.eu";
		public $version 	= "1.2.0";
	}
